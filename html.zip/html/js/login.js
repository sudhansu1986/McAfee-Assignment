$("#submitButton").click(function() {
  var formData = {
    email: $("#username").val(),
    password: $("#password").val()
  };
  $.ajax({
    url: "https://reqres.in/api/login",
    type: "POST",
    data: formData,
    success: function(data) {
      console.log(data.token);
    },
    error: function(errorThrown) {
      $(".card-error").show();
      $(".input-group-prepend").addClass("input-error");
    }
  });
});
